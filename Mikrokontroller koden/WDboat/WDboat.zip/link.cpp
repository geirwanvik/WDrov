#include "link.h"
#include "CommandList.h"
#include "imu.h"
#include "dht11.h"
#include "gps_ublox.h"
#include "Streaming.h"
#include "pins.h"
#include "mpu6000.h"
#include "hmc5843.h"

_WDlink WDlink;

void _WDlink::Init()
{
	Serial.begin(115200);
	tx.reserve(100);
	rx.reserve(100);
	rx = "";
	cmd.reserve(20);
	cmd = "";
	val.reserve(20);
	val = "";
}

enum { SEND_GPS, SEND_IMU, SEND_RELAY, SEND_MISC };

void _WDlink::Write()
{
	static byte select = 0;
	byte ret;
	tx = "$ardu,";
	switch (select)
	{
	case SEND_GPS:
		tx += Commands[GPS_LAT];
		tx += ",";
		tx += String((double)(GPS.Lattitude / 10000000.0), 7);
		tx += ",";

		tx += Commands[GPS_LON];
		tx += ",";
		tx += String((double)(GPS.Longitude / 10000000.0), 7);
		tx += ",";

		tx += Commands[GPS_ALT];
		tx += ",";
		tx += String((double)(GPS.Altitude / 100.0), 2);
		tx += ",";

		tx += Commands[GPS_GROUND_SPEED];
		tx += ",";
		tx += String((double)(GPS.Ground_Speed / 100.0), 2);
		tx += ",";

		tx += Commands[GPS_3D_SPEED];
		tx += ",";
		tx += String((double)(GPS.Speed_3d / 100.0), 2);
		tx += ",";

		tx += Commands[GPS_GROUND_COURSE];
		tx += ",";
		tx += String((double)(GPS.Ground_Course / 100.0), 2);
		tx += ",";

		tx += Commands[GPS_NUM_SATS];
		tx += ",";
		tx += GPS.NumSats;
		tx += ",";

		tx += Commands[GPS_FIX];
		tx += ",";
		tx += GPS.Fix;
		break;
	case SEND_IMU:
		tx += Commands[IMU_ROLL];
		tx += ",";
		tx += String(IMU.Roll, 1);
		tx += ",";

		tx += Commands[IMU_PITCH];
		tx += ",";
		tx += String(IMU.Pitch, 1);
		tx += ",";

		tx += Commands[IMU_HEADING];
		tx += ",";
		tx += String(IMU.Heading, 1);
		break;
	case SEND_RELAY:
		tx += Commands[RELAY_BILGE_PP];
		tx += ",";
		ret = digitalRead(BILGE_PP_IN_PIN);
		if (ret)
		{
			tx += "ON";
		}
		else
		{
			tx += "OFF";
		}
		tx += ",";

		tx += Commands[RELAY_LANTERN];
		tx += ",";
		ret = digitalRead(LANTERN_IN_PIN);
		if (ret)
		{
			tx += "ON";
		}
		else
		{
			tx += "OFF";
		}
		tx += ",";

		tx += Commands[RELAY_WIPER];
		tx += ",";
		ret = digitalRead(WIPER_IN_PIN);
		if (ret)
		{
			tx += "ON";
		}
		else
		{
			tx += "OFF";
		}
		break;
	case SEND_MISC:
		tx += Commands[DHT22_TEMP];
		tx += ",";
		tx += String(DHT.Temperature, 1);
		tx += ",";

		tx += Commands[DHT22_HUM];
		tx += ",";
		tx += String(DHT.Humidity, 1);
		break;
	}

	tx += "*";
	byte crc = CalculateCRC(tx.c_str());
	if (crc < 0x10)
	{
		tx += "0";
	}
	tx += String(crc, HEX);

	Serial << tx << endl;

	select++;
	if (select > SEND_MISC)
	{
		select = SEND_GPS;
	}
}

void _WDlink::Read()
{
	while (Serial.available())
	{
		char data = Serial.read();
		if ((data != '\n') && (data != '\r'))
		{
			rx.concat(data);
		}
		else
		{
			byte crcOK = CheckCRC(rx.c_str());
			if (crcOK)
			{
				NewMessage(rx);
			}
			rx = "";
		}
	}
}

void _WDlink::NewMessage(const String &s)
{
	int index = 0, outdex = 0;
	byte numElements = 0, i = 0;
	const char delim = ',';
	const char stop = '*';

	while (1)
	{
		index = s.indexOf(delim, index);
		if (index == -1)
		{
			break;
		}
		index++;
		numElements++;
	};
	numElements /= 2;

	index = outdex = 0;

	for (i = 0; i < numElements; i++)
	{
		index = s.indexOf(delim, index);
		index++;
		outdex = s.indexOf(delim, index);
		cmd = s.substring(index, outdex);

		index = outdex +1;
		outdex = s.indexOf(delim, index);
		val = s.substring(index, outdex);
		index = outdex;

		if (val.indexOf(stop) != -1)
		{
			index = val.indexOf(stop);
			val.remove(index, 3);
		}
		ProcessCommand(cmd, val);
	}
}

void _WDlink::ProcessCommand(const String &cmd, const String &val)
{
	int i;
	for (i = 0; i < sizeof(Commands) / sizeof(Commands[0]); i++)
	{
		if (cmd == Commands[i])
		{
			break;
		}
	}

	switch (i)
	{
	case ACC_ZERO:
		MPU.calibrateAcc();
		break;
	case MAG_CALIBRATE:
		if (val == "ON")
		{
			HMC.beginCalibration();
		}
		else
		{
			HMC.endCalibration();
		}
		break;
	case RELAY_BILGE_PP:
		if (val == "ON")
		{
			digitalWrite(BILGE_PP_OUT_PIN, ON);
		}
		else
		{
			digitalWrite(BILGE_PP_OUT_PIN, OFF);
		}
		break;
	case RELAY_LANTERN:
		if (val == "ON")
		{
			digitalWrite(LANTERN_OUT_PIN, ON);
		}
		else
		{
			digitalWrite(LANTERN_OUT_PIN, OFF);
		}
		break;
	case RELAY_WIPER:
		if (val == "ON")
		{
			digitalWrite(WIPER_OUT_PIN,ON);
		}
		else
		{
			digitalWrite(WIPER_OUT_PIN, OFF);
		}
		break;
	}
}

byte _WDlink::CalculateCRC(const char *buffer)
{
	byte c = 0;
	buffer++;
	while (*buffer != '*')
	{
		c ^= *buffer++;
	}
	return c;
}

byte _WDlink::CheckCRC(const char *buffer)
{
	byte c = 0;
	byte crc = 0;
	buffer++;
	while (*buffer != '*')
	{
		c ^= *buffer++;
	}
	buffer++;
	crc = strtoul(buffer, 0, 16);
	if (c == crc)
	{
		return true;
	}
	return false;
}